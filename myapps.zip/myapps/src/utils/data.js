(function () {
	"use strict";
}());

module.exports = {
	JSFile: ["/js/jquery-3.6.0.min.js","/bootstrap/js/bootstrap.min.js"],
	CSSFile: ["/bootstrap/css/bootstrap.min.css"],
	myJSFile: ["/js/logon.js"],
	operator: ["M","C","M+","M-"]
};
