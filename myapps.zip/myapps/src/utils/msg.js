(function () {
	"use strict";
}());
module.exports = {
	replyMessage: (code) => {
		var msg;
		switch (code) {
		default: msg = "Problems Occurance!";
			break;
		}
		return msg;
	}
};
